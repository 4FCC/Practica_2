#include <iostream>
#include <string>

class Texto {
protected:
    std::string cadena;

public:
    Texto(std::string str) : cadena(str) {}

    std::string getString() {
        return cadena;
    }

    // Resto de las funciones de Texto
};

class Parrafo : public Texto {
public:
    Parrafo(Texto* textos, int cantidad) : Texto("") {
        for (int i = 0; i < cantidad; i++) {
            cadena += textos[i].getString();
        }
    }

    long getLength() {
        return cadena.length();
    }

    char** toCharMatrix() {
        int numLines = 0;
        for (char c : cadena) {
            if (c == '\n') {
                numLines++;
            }
        }

        char** charMatrix = new char* [numLines + 1];
        char* currentLine = new char[cadena.length() + 1];
        int lineIndex = 0;
        int charIndex = 0;

        for (char c : cadena) {
            if (c != '\n') {
                currentLine[charIndex] = c;
                charIndex++;
            }
            else {
                currentLine[charIndex] = '\0';
                charMatrix[lineIndex] = currentLine;
                lineIndex++;
                charIndex = 0;
                currentLine = new char[cadena.length() + 1];
            }
        }

        charMatrix[numLines] = nullptr;
        return charMatrix;
    }
};