#include <iostream>
#include <string>

using namespace std;

class Texto {
private:
    string cadena;

public:
    Texto(string cadena) {
        this->cadena = cadena;
    }

    int getLength() {
        return cadena.length();
    }

    bool contains(char c) {
        return cadena.find(c) != string::npos;
    }

    bool contains(char c, int veces) {
        int contador = 0;
        for (int i = 0; i < cadena.length(); i++) {
            if (cadena[i] == c) {
                contador++;
            }
        }
        return contador >= veces;
    }

    string reverse() {
        string cadenaRevertida;
        for (int i = cadena.length() - 1; i >= 0; i--) {
            cadenaRevertida += cadena[i];
        }
        return cadenaRevertida;
    }

    bool palindromo() {
        return cadena == reverse();
    }

    const char* toCharArray() {
        return cadena.c_str();
    }
};

int main() {
    Texto texto("Hola");

    cout << "Longitud: " << texto.getLength() << endl;
    cout << "Contiene 'a': " << texto.contains('a') << endl;
    cout << "Contiene 'a' 2 veces: " << texto.contains('a', 2) << endl;
    cout << "Invertida: " << texto.reverse() << endl;
    cout << "Palindromo: " << texto.palindromo() << endl;

    const char* cadenaEnChar = texto.toCharArray();
    cout << "Cadena en char: " << cadenaEnChar << endl;

    delete[] cadenaEnChar;

    return 0;
}
